package com.custom.customGenerator;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CustomGeneratorApplicationTests {

	@Test
	void contextLoads() {
	}

}
